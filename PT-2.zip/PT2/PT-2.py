import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from subprocess import check_output
from flask import * 
app = Flask(__name__)
data=pd.read_csv('rainfall in india.csv')
data.head(10)
data.dropna(how='any', inplace=True)
data.info()
subdivs = data['SUBDIVISION'].unique()
num_of_subdivs = subdivs.size
print('Total # of Subdivs: ' + str(num_of_subdivs))
subdivs
data.describe()
import seaborn as sns
corrmat = data.corr(method = "spearman")
plt.figure(figsize=(18,18))
#plot heat map
g=sns.heatmap(corrmat,annot=True)
fig = plt.figure(figsize=(16,8))
ax = fig.add_subplot(111)
data.groupby('SUBDIVISION').mean().sort_values(by='ANNUAL', ascending=False)['ANNUAL'].plot(kind='bar', color='g',width=0.5,title='Subdivision wise Average Annual Rainfall', fontsize=10)
plt.xticks(rotation = 90)
plt.ylabel('Average Annual Rainfall (mm)')
ax.title.set_fontsize(30)
ax.xaxis.label.set_fontsize(20)
ax.yaxis.label.set_fontsize(20)
print(data.groupby('SUBDIVISION').mean().sort_values(by='ANNUAL', ascending=False)['ANNUAL'][[0,1,2]])
print(data.groupby('SUBDIVISION').mean().sort_values(by='ANNUAL', ascending=False)['ANNUAL'][[33,34,35]])
from sklearn.model_selection import train_test_split
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
division_data = np.asarray(data[['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL',
       'AUG', 'SEP', 'OCT', 'NOV', 'DEC']])

X = None; y = None
for i in range(division_data.shape[1]-3):
    if X is None:
        X = division_data[:, i:i+3]
        y = division_data[:, i+3]
    else:
        X = np.concatenate((X, division_data[:, i:i+3]), axis=0)
        y = np.concatenate((y, division_data[:, i+3]), axis=0)
        
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)
X
y
X_test
y_test
X_train
y_train
from sklearn import linear_model

# linear model
reg = linear_model.ElasticNet(alpha=0.5)
reg.fit(X_train, y_train)
y_pred = reg.predict(X_test)
print (mean_absolute_error(y_test, y_pred))
def fun(i1,i2,i3,i4):
     l1=[i1]
     l2=[i2]
     l3=[i3]
     l4=[i4]
     d={"JAN":l1,"FEB":l2,"MAR":l3,"APR":l4}
     d=pd.DataFrame(d)
     return reg.predict(d)
@app.route('/')  
def ho():  
    return render_template("Welcomepage.html");
@app.route('/fis',methods = ['POST'])  
def hoo():  
    return render_template("fis.html");
@app.route('/input',methods = ['POST'])  
def home():  
      i1=request.form['i1']  
      i2=request.form['i2']
      i3=request.form['i3']
      i4=request.form['i4']
      f=fun(i1,i2,i3,i4)
      return render_template("output.html",name=str(f[0]));
app.run()

